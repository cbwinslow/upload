// Global state
let ingestionState = {
  isRunning: false,
  shouldStop: false,
  collectedData: [],
  currentScript: { content: '', type: '', filename: '' }
};

// Endpoint data
const endpoints = [
  { value: 'bill', label: 'Bills' },
  { value: 'amendment', label: 'Amendments' },
  { value: 'summaries', label: 'Bill Summaries' },
  { value: 'congress', label: 'Congress Info' },
  { value: 'member', label: 'Members' },
  { value: 'committee', label: 'Committees' },
  { value: 'committee-report', label: 'Committee Reports' },
  { value: 'committee-print', label: 'Committee Prints' },
  { value: 'committee-meeting', label: 'Committee Meetings' },
  { value: 'hearing', label: 'Hearings' },
  { value: 'congressional-record', label: 'Congressional Record' },
  { value: 'daily-congressional-record', label: 'Daily Congressional Record' },
  { value: 'bound-congressional-record', label: 'Bound Congressional Record' },
  { value: 'house-communication', label: 'House Communications' },
  { value: 'senate-communication', label: 'Senate Communications' },
  { value: 'nomination', label: 'Nominations' },
  { value: 'treaty', label: 'Treaties' }
];

// Single endpoint download with progress tracking
function startIngestion() {
  const endpoint = document.getElementById('endpoint').value;
  const congress = document.getElementById('congress').value;
  const format = document.getElementById('format').value;
  const limit = document.getElementById('limit').value;
  const apiKey = document.getElementById('apiKey').value;
  
  const statusDiv = document.getElementById('singleStatus');
  
  if (!apiKey) {
    showStatus(statusDiv, 'error', 'Please enter an API key');
    return;
  }
  
  if (!congress || congress < 1 || congress > 118) {
    showStatus(statusDiv, 'error', 'Please enter a valid congress number (1-118)');
    return;
  }
  
  ingestionState.isRunning = true;
  ingestionState.shouldStop = false;
  ingestionState.collectedData = [];
  
  document.getElementById('startIngestionBtn').disabled = true;
  document.getElementById('stopIngestionBtn').disabled = false;
  document.getElementById('downloadDataBtn').disabled = true;
  
  document.getElementById('progressSection').classList.remove('hidden');
  document.getElementById('activityLog').classList.remove('hidden');
  
  addLogEntry('Starting ingestion...');
  showStatus(statusDiv, 'info', 'Ingestion in progress...');
  
  downloadWithPagination(endpoint, congress, format, limit, apiKey, 0);
}

function stopIngestion() {
  ingestionState.shouldStop = true;
  ingestionState.isRunning = false;
  
  document.getElementById('startIngestionBtn').disabled = false;
  document.getElementById('stopIngestionBtn').disabled = true;
  
  if (ingestionState.collectedData.length > 0) {
    document.getElementById('downloadDataBtn').disabled = false;
  }
  
  addLogEntry('Ingestion stopped by user');
  showStatus(document.getElementById('singleStatus'), 'warning', 'Ingestion stopped');
}

function downloadWithPagination(endpoint, congress, format, limit, apiKey, offset) {
  if (ingestionState.shouldStop) {
    return;
  }
  
  const url = `https://api.congress.gov/v3/${endpoint}?congress=${congress}&format=${format}&limit=${limit}&offset=${offset}&api_key=${apiKey}`;
  
  addLogEntry(`Fetching offset ${offset}, limit ${limit}...`);
  
  fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return format === 'json' ? response.json() : response.text();
    })
    .then(data => {
      if (ingestionState.shouldStop) {
        return;
      }
      
      let items = [];
      let hasMore = false;
      
      if (format === 'json') {
        items = data[endpoint] || [];
        hasMore = data.pagination && data.pagination.next;
      } else {
        items = [data];
        hasMore = false;
      }
      
      ingestionState.collectedData = ingestionState.collectedData.concat(items);
      
      const totalCollected = ingestionState.collectedData.length;
      updateProgress(totalCollected, hasMore);
      addLogEntry(`Collected ${items.length} items (total: ${totalCollected})`);
      
      if (hasMore && !ingestionState.shouldStop) {
        setTimeout(() => {
          downloadWithPagination(endpoint, congress, format, limit, apiKey, offset + parseInt(limit));
        }, 750);
      } else {
        completeIngestion(endpoint, congress, format);
      }
    })
    .catch(error => {
      addLogEntry(`Error: ${error.message}`);
      showStatus(document.getElementById('singleStatus'), 'error', `Error: ${error.message}`);
      ingestionState.isRunning = false;
      document.getElementById('startIngestionBtn').disabled = false;
      document.getElementById('stopIngestionBtn').disabled = true;
      if (ingestionState.collectedData.length > 0) {
        document.getElementById('downloadDataBtn').disabled = false;
      }
    });
}

function completeIngestion(endpoint, congress, format) {
  ingestionState.isRunning = false;
  document.getElementById('startIngestionBtn').disabled = false;
  document.getElementById('stopIngestionBtn').disabled = true;
  document.getElementById('downloadDataBtn').disabled = false;
  
  addLogEntry(`Ingestion complete! Total items: ${ingestionState.collectedData.length}`);
  showStatus(document.getElementById('singleStatus'), 'success', `Successfully collected ${ingestionState.collectedData.length} items`);
}

function updateProgress(itemsCollected, hasMore) {
  const progressBar = document.getElementById('progressBar');
  const progressText = document.getElementById('progressText');
  
  if (hasMore) {
    progressBar.style.width = '100%';
    progressBar.textContent = '';
    progressBar.style.backgroundImage = 'linear-gradient(90deg, var(--color-primary) 0%, var(--color-primary-hover) 50%, var(--color-primary) 100%)';
    progressBar.style.backgroundSize = '200% 100%';
    progressBar.style.animation = 'shimmer 1.5s infinite';
    progressText.textContent = `Collected ${itemsCollected} items... fetching more`;
  } else {
    progressBar.style.width = '100%';
    progressBar.textContent = '100%';
    progressBar.style.backgroundImage = 'none';
    progressBar.style.backgroundColor = 'var(--color-primary)';
    progressBar.style.animation = 'none';
    progressText.textContent = `Complete: ${itemsCollected} items collected`;
  }
}

function addLogEntry(message) {
  const logContent = document.getElementById('logContent');
  const timestamp = new Date().toLocaleTimeString();
  const entry = document.createElement('div');
  entry.textContent = `[${timestamp}] ${message}`;
  entry.style.marginBottom = 'var(--space-4)';
  logContent.appendChild(entry);
  logContent.scrollTop = logContent.scrollHeight;
}

function downloadCollectedData() {
  const endpoint = document.getElementById('endpoint').value;
  const congress = document.getElementById('congress').value;
  const format = document.getElementById('format').value;
  
  const data = {
    endpoint: endpoint,
    congress: parseInt(congress),
    downloaded_at: new Date().toISOString(),
    item_count: ingestionState.collectedData.length,
    items: ingestionState.collectedData
  };
  
  const blob = new Blob(
    [JSON.stringify(data, null, 2)],
    { type: 'application/json' }
  );
  const filename = `${endpoint}_${congress}_${Date.now()}.json`;
  downloadFile(blob, filename);
  addLogEntry(`Downloaded: ${filename}`);
}

// Legacy function for backward compatibility
function downloadSingleEndpoint() {
  const endpoint = document.getElementById('endpoint').value;
  const congress = document.getElementById('congress').value;
  const format = document.getElementById('format').value;
  const limit = document.getElementById('limit').value;
  const apiKey = document.getElementById('apiKey').value;
  
  const statusDiv = document.getElementById('singleStatus');
  
  if (!apiKey) {
    showStatus(statusDiv, 'error', 'Please enter an API key');
    return;
  }
  
  if (!congress || congress < 1 || congress > 118) {
    showStatus(statusDiv, 'error', 'Please enter a valid congress number (1-118)');
    return;
  }
  
  showStatus(statusDiv, 'info', 'Downloading data...');
  
  const url = `https://api.congress.gov/v3/${endpoint}?congress=${congress}&format=${format}&limit=${limit}&api_key=${apiKey}`;
  
  fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return format === 'json' ? response.json() : response.text();
    })
    .then(data => {
      const blob = new Blob(
        [format === 'json' ? JSON.stringify(data, null, 2) : data],
        { type: format === 'json' ? 'application/json' : 'application/xml' }
      );
      const filename = `${endpoint}_${congress}_${Date.now()}.${format}`;
      downloadFile(blob, filename);
      showStatus(statusDiv, 'success', `Successfully downloaded ${filename}`);
    })
    .catch(error => {
      showStatus(statusDiv, 'error', `Error: ${error.message}`);
    });
}

// Bulk endpoint functions
function selectAllEndpoints() {
  const checkboxes = document.querySelectorAll('#endpointCheckboxes input[type="checkbox"]');
  checkboxes.forEach(cb => cb.checked = true);
  updateSummary();
}

function deselectAllEndpoints() {
  const checkboxes = document.querySelectorAll('#endpointCheckboxes input[type="checkbox"]');
  checkboxes.forEach(cb => cb.checked = false);
  updateSummary();
}

function getSelectedEndpoints() {
  const checkboxes = document.querySelectorAll('#endpointCheckboxes input[type="checkbox"]:checked');
  return Array.from(checkboxes).map(cb => cb.value);
}

function getEndpointLabel(value) {
  const endpoint = endpoints.find(e => e.value === value);
  return endpoint ? endpoint.label : value;
}

function updateSummary() {
  const selectedEndpoints = getSelectedEndpoints();
  const congressStart = parseInt(document.getElementById('congressStart').value);
  const congressEnd = parseInt(document.getElementById('congressEnd').value);
  const format = document.getElementById('bulkFormat').value;
  const limit = document.getElementById('bulkLimit').value;
  const maxItems = document.getElementById('maxItems').value;
  
  const summaryDiv = document.getElementById('bulkSummary');
  const summaryContent = document.getElementById('summaryContent');
  
  if (selectedEndpoints.length === 0 || !congressStart || !congressEnd) {
    summaryDiv.classList.add('hidden');
    return;
  }
  
  if (congressStart > congressEnd || congressStart < 1 || congressEnd > 118) {
    summaryContent.innerHTML = '<p class="status status--error">Invalid congress range</p>';
    summaryDiv.classList.remove('hidden');
    return;
  }
  
  const congressCount = congressEnd - congressStart + 1;
  const totalCombinations = selectedEndpoints.length * congressCount;
  
  let html = `
    <div class="summary-item"><strong>Endpoints:</strong> ${selectedEndpoints.length} (${selectedEndpoints.map(getEndpointLabel).join(', ')})</div>
    <div class="summary-item"><strong>Congress Range:</strong> ${congressStart} to ${congressEnd} (${congressCount} congresses)</div>
    <div class="summary-item"><strong>Total Downloads:</strong> ${totalCombinations} endpoint/congress combinations</div>
    <div class="summary-item"><strong>Format:</strong> ${format.toUpperCase()}</div>
    <div class="summary-item"><strong>Items per Request:</strong> ${limit}</div>
    ${maxItems ? `<div class="summary-item"><strong>Max Items per Download:</strong> ${maxItems}</div>` : ''}
    <div class="summary-item"><strong>Rate Limit:</strong> 5000 requests/hour (750ms delay between requests)</div>
  `;
  
  summaryContent.innerHTML = html;
  summaryDiv.classList.remove('hidden');
}

function showScriptPreview(content, type, filename) {
  ingestionState.currentScript = { content, type, filename };
  
  document.getElementById('scriptContent').textContent = content;
  document.getElementById('scriptTypeIndicator').textContent = `${type.toUpperCase()} Script`;
  document.getElementById('scriptPreviewCard').classList.remove('hidden');
  document.getElementById('scriptPreviewCard').scrollIntoView({ behavior: 'smooth' });
}

function closeScriptPreview() {
  document.getElementById('scriptPreviewCard').classList.add('hidden');
}

function copyScriptToClipboard() {
  const content = ingestionState.currentScript.content;
  
  navigator.clipboard.writeText(content).then(() => {
    showStatus(document.getElementById('scriptStatus'), 'success', 'Copied to clipboard!');
    setTimeout(() => {
      document.getElementById('scriptStatus').classList.add('hidden');
    }, 3000);
  }).catch(err => {
    showStatus(document.getElementById('scriptStatus'), 'error', 'Failed to copy to clipboard');
  });
}

function downloadScript() {
  const { content, filename, type } = ingestionState.currentScript;
  const blob = new Blob([content], { type: type === 'python' ? 'text/x-python' : 'text/x-shellscript' });
  downloadFile(blob, filename);
  showStatus(document.getElementById('scriptStatus'), 'success', `Downloaded: ${filename}`);
}

function generatePythonScript() {
  const selectedEndpoints = getSelectedEndpoints();
  const congressStart = parseInt(document.getElementById('congressStart').value);
  const congressEnd = parseInt(document.getElementById('congressEnd').value);
  const format = document.getElementById('bulkFormat').value;
  const limit = document.getElementById('bulkLimit').value;
  const maxItems = document.getElementById('maxItems').value || 'None';
  
  const statusDiv = document.getElementById('bulkStatus');
  
  if (selectedEndpoints.length === 0) {
    showStatus(statusDiv, 'error', 'Please select at least one endpoint');
    return;
  }
  
  if (!congressStart || !congressEnd || congressStart > congressEnd) {
    showStatus(statusDiv, 'error', 'Please enter a valid congress range');
    return;
  }
  
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
  const endpointsList = selectedEndpoints.map(e => `'${e}'`).join(', ');
  
  const pythonScript = `#!/usr/bin/env python3
"""
Congress.gov API Bulk Download Script
Generated: ${new Date().toLocaleString()}
Endpoints: ${selectedEndpoints.map(getEndpointLabel).join(', ')}
Congress Range: ${congressStart} to ${congressEnd}

Usage:
    python congress_bulk_download.py YOUR_API_KEY
    
Or set API key as environment variable:
    export CONGRESS_API_KEY=your_key_here
    python congress_bulk_download.py
"""

import requests
import json
import time
import argparse
import os
import sys
from pathlib import Path
from datetime import datetime
import logging
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configuration
class Config:
    ENDPOINTS = [${endpointsList}]
    CONGRESS_START = ${congressStart}
    CONGRESS_END = ${congressEnd}
    FORMAT = '${format}'
    LIMIT = ${limit}
    MAX_ITEMS = ${maxItems}  # None for unlimited
    RATE_LIMIT_DELAY = 0.75  # seconds (750ms)
    MAX_REQUESTS_PER_HOUR = 5000
    RETRY_WAIT = 60  # seconds
    MAX_RETRIES = 3
    BASE_URL = 'https://api.congress.gov/v3'
    DATA_DIR = Path('data')
    LOG_DIR = Path('logs')

class RateLimiter:
    """Track and enforce API rate limits"""
    def __init__(self, max_per_hour: int, delay_seconds: float):
        self.max_per_hour = max_per_hour
        self.delay_seconds = delay_seconds
        self.request_times = []
    
    def wait_if_needed(self):
        """Wait if rate limit would be exceeded"""
        now = time.time()
        # Remove requests older than 1 hour
        self.request_times = [t for t in self.request_times if now - t < 3600]
        
        if len(self.request_times) >= self.max_per_hour:
            wait_time = 3600 - (now - self.request_times[0])
            if wait_time > 0:
                logging.warning(f"Rate limit reached. Waiting {wait_time:.0f} seconds...")
                time.sleep(wait_time)
        
        # Standard delay between requests
        time.sleep(self.delay_seconds)
        self.request_times.append(time.time())

class CongressAPIDownloader:
    """Download data from Congress.gov API"""
    
    def __init__(self, api_key: str, config: Config):
        self.api_key = api_key
        self.config = config
        self.rate_limiter = RateLimiter(config.MAX_REQUESTS_PER_HOUR, config.RATE_LIMIT_DELAY)
        self.setup_logging()
        self.setup_directories()
        self.stats = {'success': 0, 'failed': 0, 'items_downloaded': 0}
    
    def setup_logging(self):
        """Configure logging to file and console"""
        self.config.LOG_DIR.mkdir(exist_ok=True)
        log_file = self.config.LOG_DIR / f'download_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler(sys.stdout)
            ]
        )
        logging.info("Congress.gov API Bulk Downloader initialized")
        logging.info(f"Endpoints: {', '.join(self.config.ENDPOINTS)}")
        logging.info(f"Congress range: {self.config.CONGRESS_START} to {self.config.CONGRESS_END}")
    
    def setup_directories(self):
        """Create necessary directories"""
        for endpoint in self.config.ENDPOINTS:
            for congress in range(self.config.CONGRESS_START, self.config.CONGRESS_END + 1):
                dir_path = self.config.DATA_DIR / endpoint / str(congress)
                dir_path.mkdir(parents=True, exist_ok=True)
    
    def make_request(self, url: str, retries: int = 0) -> Optional[Dict]:
        """Make API request with retry logic"""
        self.rate_limiter.wait_if_needed()
        
        try:
            response = requests.get(url, timeout=30)
            
            if response.status_code == 429:  # Rate limit
                if retries < self.config.MAX_RETRIES:
                    logging.warning(f"Rate limited. Retry {retries + 1}/{self.config.MAX_RETRIES}")
                    time.sleep(self.config.RETRY_WAIT * (2 ** retries))  # Exponential backoff
                    return self.make_request(url, retries + 1)
                else:
                    logging.error(f"Max retries reached for {url}")
                    return None
            
            response.raise_for_status()
            return response.json() if self.config.FORMAT == 'json' else {'content': response.text}
        
        except requests.exceptions.RequestException as e:
            logging.error(f"Request failed: {url} - {str(e)}")
            if retries < self.config.MAX_RETRIES:
                time.sleep(self.config.RETRY_WAIT)
                return self.make_request(url, retries + 1)
            return None
    
    def download_endpoint_congress(self, endpoint: str, congress: int) -> bool:
        """Download all data for one endpoint/congress combination"""
        logging.info(f"Starting download: {endpoint} / Congress {congress}")
        
        all_data = []
        offset = 0
        items_collected = 0
        
        while True:
            url = f"{self.config.BASE_URL}/{endpoint}?congress={congress}&format={self.config.FORMAT}&limit={self.config.LIMIT}&offset={offset}&api_key={self.api_key}"
            
            data = self.make_request(url)
            if not data:
                logging.error(f"Failed to download {endpoint} / Congress {congress}")
                return False
            
            # Extract items from response
            items = data.get(endpoint, []) if self.config.FORMAT == 'json' else [data.get('content', '')]
            
            if not items:
                break
            
            all_data.extend(items)
            items_collected += len(items)
            
            logging.info(f"{endpoint} / Congress {congress}: Collected {items_collected} items")
            
            # Check if we've reached max items
            if self.config.MAX_ITEMS and items_collected >= self.config.MAX_ITEMS:
                all_data = all_data[:self.config.MAX_ITEMS]
                break
            
            # Check if there are more items
            pagination = data.get('pagination', {})
            if not pagination.get('next'):
                break
            
            offset += self.config.LIMIT
        
        # Save data
        self.save_data(all_data, endpoint, congress)
        self.stats['items_downloaded'] += len(all_data)
        logging.info(f"Completed: {endpoint} / Congress {congress} - {len(all_data)} items")
        return True
    
    def save_data(self, data: List, endpoint: str, congress: int):
        """Save data to organized file structure"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{endpoint}_{congress}_{timestamp}.{self.config.FORMAT}"
        filepath = self.config.DATA_DIR / endpoint / str(congress) / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            if self.config.FORMAT == 'json':
                json.dump({
                    'endpoint': endpoint,
                    'congress': congress,
                    'downloaded_at': datetime.now().isoformat(),
                    'item_count': len(data),
                    'items': data
                }, f, indent=2)
            else:
                f.write('\n'.join(data))
        
        logging.info(f"Saved: {filepath}")
    
    def run(self):
        """Main execution"""
        logging.info("Starting bulk download...")
        start_time = time.time()
        
        total_tasks = len(self.config.ENDPOINTS) * (self.config.CONGRESS_END - self.config.CONGRESS_START + 1)
        completed = 0
        
        for endpoint in self.config.ENDPOINTS:
            for congress in range(self.config.CONGRESS_START, self.config.CONGRESS_END + 1):
                completed += 1
                progress = (completed / total_tasks) * 100
                
                logging.info(f"Progress: {completed}/{total_tasks} ({progress:.1f}%)")
                
                success = self.download_endpoint_congress(endpoint, congress)
                if success:
                    self.stats['success'] += 1
                else:
                    self.stats['failed'] += 1
        
        elapsed_time = time.time() - start_time
        
        logging.info("="*50)
        logging.info("Download Complete!")
        logging.info(f"Successful: {self.stats['success']}")
        logging.info(f"Failed: {self.stats['failed']}")
        logging.info(f"Total items downloaded: {self.stats['items_downloaded']}")
        logging.info(f"Time elapsed: {elapsed_time:.2f} seconds")
        logging.info("="*50)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Download bulk data from Congress.gov API')
    parser.add_argument('api_key', nargs='?', help='Congress.gov API key')
    args = parser.parse_args()
    
    # Get API key from argument or environment variable
    api_key = args.api_key or os.environ.get('CONGRESS_API_KEY')
    
    if not api_key:
        print("Error: API key required")
        print("Usage: python congress_bulk_download.py YOUR_API_KEY")
        print("Or set environment variable: export CONGRESS_API_KEY=your_key")
        sys.exit(1)
    
    try:
        downloader = CongressAPIDownloader(api_key, Config())
        downloader.run()
    except KeyboardInterrupt:
        logging.info("Download interrupted by user")
        sys.exit(0)
    except Exception as e:
        logging.error(f"Fatal error: {str(e)}", exc_info=True)
        sys.exit(1)
`;
  
  const filename = `congress_bulk_download_${timestamp}.py`;
  showScriptPreview(pythonScript, 'python', filename);
  showStatus(statusDiv, 'success', `Python script generated: ${filename}`);
}

function generateBashScript() {
  const selectedEndpoints = getSelectedEndpoints();
  const congressStart = parseInt(document.getElementById('congressStart').value);
  const congressEnd = parseInt(document.getElementById('congressEnd').value);
  const format = document.getElementById('bulkFormat').value;
  const limit = document.getElementById('bulkLimit').value;
  const maxItems = document.getElementById('maxItems').value || 'unlimited';
  
  const statusDiv = document.getElementById('bulkStatus');
  
  if (selectedEndpoints.length === 0) {
    showStatus(statusDiv, 'error', 'Please select at least one endpoint');
    return;
  }
  
  if (!congressStart || !congressEnd || congressStart > congressEnd) {
    showStatus(statusDiv, 'error', 'Please enter a valid congress range');
    return;
  }
  
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
  const endpointsArray = selectedEndpoints.map(e => `"${e}"`).join(' ');
  
  const bashScript = `#!/bin/bash
# Congress.gov API Bulk Download Script
# Generated: ${new Date().toLocaleString()}
# Endpoints: ${selectedEndpoints.map(getEndpointLabel).join(', ')}
# Congress Range: ${congressStart} to ${congressEnd}
#
# Usage:
#   ./congress_bulk_download.sh YOUR_API_KEY
#
# Or set API key as environment variable:
#   export CONGRESS_API_KEY=your_key_here
#   ./congress_bulk_download.sh

set -e  # Exit on error

# Configuration
API_KEY="\${1:-\${CONGRESS_API_KEY}}"
ENDPOINTS=(${endpointsArray})
CONGRESS_START=${congressStart}
CONGRESS_END=${congressEnd}
FORMAT="${format}"
LIMIT=${limit}
MAX_ITEMS=${maxItems === 'unlimited' ? '0' : maxItems}  # 0 for unlimited
RATE_LIMIT_DELAY=0.75  # seconds
BASE_URL="https://api.congress.gov/v3"
DATA_DIR="data"
LOG_DIR="logs"
RETRY_WAIT=60
MAX_RETRIES=3

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'  # No Color

# Statistics
SUCCESS_COUNT=0
FAIL_COUNT=0
ITEMS_DOWNLOADED=0

# Check for API key
if [ -z "$API_KEY" ]; then
    echo -e "\${RED}Error: API key required\${NC}"
    echo "Usage: ./congress_bulk_download.sh YOUR_API_KEY"
    echo "Or set environment variable: export CONGRESS_API_KEY=your_key"
    exit 1
fi

# Create directories
mkdir -p "$LOG_DIR"
for endpoint in "\${ENDPOINTS[@]}"; do
    for congress in $(seq $CONGRESS_START $CONGRESS_END); do
        mkdir -p "$DATA_DIR/$endpoint/$congress"
    done
done

# Setup logging
LOG_FILE="$LOG_DIR/download_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG_FILE")
exec 2>&1

echo "Congress.gov API Bulk Downloader"
echo "================================="
echo "Generated: $(date)"
echo "Endpoints: ${selectedEndpoints.map(getEndpointLabel).join(', ')}"
echo "Congress range: $CONGRESS_START to $CONGRESS_END"
echo ""

# Rate limiting function
rate_limit() {
    sleep $RATE_LIMIT_DELAY
}

# Retry function with exponential backoff
retry_request() {
    local url="$1"
    local output_file="$2"
    local retry=0
    
    while [ $retry -lt $MAX_RETRIES ]; do
        if curl -f -s -o "$output_file" "$url"; then
            return 0
        else
            retry=$((retry + 1))
            if [ $retry -lt $MAX_RETRIES ]; then
                local wait_time=$((RETRY_WAIT * (2 ** (retry - 1))))
                echo -e "\${YELLOW}Request failed. Retry $retry/$MAX_RETRIES after ${wait_time}s\${NC}"
                sleep $wait_time
            fi
        fi
    done
    
    return 1
}

# Download function
download_data() {
    local endpoint="$1"
    local congress="$2"
    local offset=0
    local items_collected=0
    local temp_dir="$DATA_DIR/$endpoint/$congress/temp"
    
    mkdir -p "$temp_dir"
    
    echo -e "\${GREEN}Downloading: $endpoint / Congress $congress\${NC}"
    
    while true; do
        local url="$BASE_URL/$endpoint?congress=$congress&format=$FORMAT&limit=$LIMIT&offset=$offset&api_key=$API_KEY"
        local temp_file="$temp_dir/page_$offset.$FORMAT"
        
        rate_limit
        
        if retry_request "$url" "$temp_file"; then
            # Check if we got data (simple check for file size)
            if [ ! -s "$temp_file" ]; then
                break
            fi
            
            # Count items (rough estimate for JSON)
            if [ "$FORMAT" = "json" ] && command -v jq &> /dev/null; then
                local count=$(jq -r ".${endpoint} | length" "$temp_file" 2>/dev/null || echo "0")
                items_collected=$((items_collected + count))
                
                if [ "$count" -eq 0 ]; then
                    break
                fi
            else
                items_collected=$((items_collected + LIMIT))
            fi
            
            echo "  Collected: $items_collected items"
            
            # Check max items limit
            if [ $MAX_ITEMS -gt 0 ] && [ $items_collected -ge $MAX_ITEMS ]; then
                break
            fi
            
            offset=$((offset + LIMIT))
        else
            echo -e "\${RED}Failed to download: $endpoint / Congress $congress\${NC}"
            FAIL_COUNT=$((FAIL_COUNT + 1))
            rm -rf "$temp_dir"
            return 1
        fi
    done
    
    # Combine all pages into single file
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local output_file="$DATA_DIR/$endpoint/$congress/${endpoint}_${congress}_${timestamp}.$FORMAT"
    
    if [ "$FORMAT" = "json" ] && command -v jq &> /dev/null; then
        # Use jq to properly combine JSON files
        echo '{' > "$output_file"
        echo '  "endpoint": "'"$endpoint"'",
        echo '  "congress": '"$congress"',
        echo '  "downloaded_at": "'"$(date -Iseconds)"'",
        echo '  "items": [' >> "$output_file"
        
        local first=true
        for file in "$temp_dir"/*.$FORMAT; do
            if [ -f "$file" ]; then
                if [ "$first" = true ]; then
                    first=false
                else
                    echo ',' >> "$output_file"
                fi
                jq -r ".${endpoint}[]" "$file" >> "$output_file" 2>/dev/null || true
            fi
        done
        
        echo '  ]' >> "$output_file"
        echo '}' >> "$output_file"
    else
        # Simple concatenation for XML or if jq not available
        cat "$temp_dir"/*.$FORMAT > "$output_file" 2>/dev/null || true
    fi
    
    rm -rf "$temp_dir"
    
    echo -e "\${GREEN}Saved: $output_file ($items_collected items)\${NC}"
    SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    ITEMS_DOWNLOADED=$((ITEMS_DOWNLOADED + items_collected))
    
    return 0
}

# Error handling
trap 'echo -e "\${RED}Script interrupted\${NC}"; exit 130' INT TERM

# Main loop
START_TIME=$(date +%s)
TOTAL_TASKS=$((\${#ENDPOINTS[@]} * (CONGRESS_END - CONGRESS_START + 1)))
COMPLETED=0

for endpoint in "\${ENDPOINTS[@]}"; do
    for congress in $(seq $CONGRESS_START $CONGRESS_END); do
        COMPLETED=$((COMPLETED + 1))
        PROGRESS=$((COMPLETED * 100 / TOTAL_TASKS))
        
        echo ""
        echo "Progress: $COMPLETED/$TOTAL_TASKS ($PROGRESS%)"
        
        download_data "$endpoint" "$congress"
    done
done

# Final statistics
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))

echo ""
echo "=================================================="
echo -e "\${GREEN}Download Complete!\${NC}"
echo "Successful: $SUCCESS_COUNT"
echo "Failed: $FAIL_COUNT"
echo "Total items downloaded: $ITEMS_DOWNLOADED"
echo "Time elapsed: ${ELAPSED}s"
echo "=================================================="
`;
  
  const filename = `congress_bulk_download_${timestamp}.sh`;
  showScriptPreview(bashScript, 'bash', filename);
  showStatus(statusDiv, 'success', `Bash script generated: ${filename}`);
}

// Helper functions
function downloadFile(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function showStatus(element, type, message) {
  element.className = `status status--${type}`;
  element.textContent = message;
  element.classList.remove('hidden');
}

function downloadSQLMigration() {
  const sqlScript = `-- Congress.gov API Database Migration Script
-- Generated: ${new Date().toLocaleString()}
-- Database: PostgreSQL (adaptable to MySQL/SQLite)

-- Enable UUID extension (PostgreSQL)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Bills Table
CREATE TABLE bills (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bill_number VARCHAR(50) NOT NULL,
    bill_type VARCHAR(20) NOT NULL,
    congress INTEGER NOT NULL,
    title TEXT,
    introduced_date DATE,
    latest_action_date DATE,
    latest_action_text TEXT,
    sponsor_name VARCHAR(255),
    sponsor_party VARCHAR(50),
    sponsor_state VARCHAR(2),
    committee_count INTEGER DEFAULT 0,
    cosponsors_count INTEGER DEFAULT 0,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(bill_number, bill_type, congress)
);

CREATE INDEX idx_bills_congress ON bills(congress);
CREATE INDEX idx_bills_type ON bills(bill_type);
CREATE INDEX idx_bills_introduced ON bills(introduced_date);
CREATE INDEX idx_bills_sponsor ON bills(sponsor_name);

-- Amendments Table
CREATE TABLE amendments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    amendment_number VARCHAR(50) NOT NULL,
    amendment_type VARCHAR(20) NOT NULL,
    congress INTEGER NOT NULL,
    purpose TEXT,
    submitted_date DATE,
    latest_action_date DATE,
    latest_action_text TEXT,
    sponsor_name VARCHAR(255),
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(amendment_number, amendment_type, congress)
);

CREATE INDEX idx_amendments_congress ON amendments(congress);
CREATE INDEX idx_amendments_type ON amendments(amendment_type);

-- Members Table
CREATE TABLE members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bioguide_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    full_name VARCHAR(255),
    party VARCHAR(50),
    state VARCHAR(2),
    district VARCHAR(10),
    chamber VARCHAR(20),
    terms JSONB,
    birth_year INTEGER,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_members_party ON members(party);
CREATE INDEX idx_members_state ON members(state);
CREATE INDEX idx_members_chamber ON members(chamber);

-- Committees Table
CREATE TABLE committees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    committee_code VARCHAR(20) UNIQUE NOT NULL,
    committee_name VARCHAR(255) NOT NULL,
    chamber VARCHAR(20),
    committee_type VARCHAR(50),
    parent_committee_code VARCHAR(20),
    is_subcommittee BOOLEAN DEFAULT FALSE,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_committees_chamber ON committees(chamber);
CREATE INDEX idx_committees_type ON committees(committee_type);

-- Committee Reports Table
CREATE TABLE committee_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_number VARCHAR(50) NOT NULL,
    report_type VARCHAR(20) NOT NULL,
    congress INTEGER NOT NULL,
    title TEXT,
    issued_date DATE,
    committee_name VARCHAR(255),
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(report_number, report_type, congress)
);

CREATE INDEX idx_reports_congress ON committee_reports(congress);
CREATE INDEX idx_reports_issued ON committee_reports(issued_date);

-- Hearings Table
CREATE TABLE hearings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    hearing_number VARCHAR(50),
    congress INTEGER NOT NULL,
    chamber VARCHAR(20),
    title TEXT,
    hearing_date DATE,
    committee_name VARCHAR(255),
    jacket_number VARCHAR(50),
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_hearings_congress ON hearings(congress);
CREATE INDEX idx_hearings_date ON hearings(hearing_date);
CREATE INDEX idx_hearings_chamber ON hearings(chamber);

-- Nominations Table
CREATE TABLE nominations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nomination_number VARCHAR(50) NOT NULL,
    congress INTEGER NOT NULL,
    nominee_name VARCHAR(255),
    position TEXT,
    organization VARCHAR(255),
    received_date DATE,
    latest_action_date DATE,
    latest_action_text TEXT,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(nomination_number, congress)
);

CREATE INDEX idx_nominations_congress ON nominations(congress);
CREATE INDEX idx_nominations_received ON nominations(received_date);

-- Treaties Table
CREATE TABLE treaties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    treaty_number VARCHAR(50) NOT NULL,
    congress INTEGER NOT NULL,
    treaty_suffix VARCHAR(10),
    title TEXT,
    transmitted_date DATE,
    topic VARCHAR(255),
    country VARCHAR(100),
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(treaty_number, congress)
);

CREATE INDEX idx_treaties_congress ON treaties(congress);
CREATE INDEX idx_treaties_country ON treaties(country);

-- Congressional Record Table
CREATE TABLE congressional_record (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    congress INTEGER NOT NULL,
    session INTEGER,
    issue_date DATE NOT NULL,
    volume_number INTEGER,
    issue_number INTEGER,
    section VARCHAR(50),
    full_text TEXT,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_record_congress ON congressional_record(congress);
CREATE INDEX idx_record_date ON congressional_record(issue_date);
CREATE INDEX idx_record_section ON congressional_record(section);

-- Communications Table (House & Senate)
CREATE TABLE communications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    communication_number VARCHAR(50) NOT NULL,
    chamber VARCHAR(20) NOT NULL,
    congress INTEGER NOT NULL,
    communication_type VARCHAR(100),
    received_date DATE,
    title TEXT,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(communication_number, chamber, congress)
);

CREATE INDEX idx_comms_congress ON communications(congress);
CREATE INDEX idx_comms_chamber ON communications(chamber);
CREATE INDEX idx_comms_type ON communications(communication_type);

-- Bill Summaries Table
CREATE TABLE bill_summaries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bill_id UUID REFERENCES bills(id),
    bill_number VARCHAR(50) NOT NULL,
    congress INTEGER NOT NULL,
    version_code VARCHAR(20),
    action_date DATE,
    action_desc VARCHAR(255),
    summary_text TEXT,
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_summaries_bill ON bill_summaries(bill_number, congress);
CREATE INDEX idx_summaries_version ON bill_summaries(version_code);

-- Committee Meetings Table
CREATE TABLE committee_meetings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id VARCHAR(100) UNIQUE,
    congress INTEGER NOT NULL,
    chamber VARCHAR(20),
    committee_code VARCHAR(20),
    meeting_date TIMESTAMP,
    title TEXT,
    location VARCHAR(255),
    meeting_type VARCHAR(50),
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_meetings_congress ON committee_meetings(congress);
CREATE INDEX idx_meetings_date ON committee_meetings(meeting_date);
CREATE INDEX idx_meetings_committee ON committee_meetings(committee_code);

-- Committee Prints Table
CREATE TABLE committee_prints (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    jacket_number VARCHAR(50) UNIQUE,
    congress INTEGER NOT NULL,
    chamber VARCHAR(20),
    print_number VARCHAR(50),
    title TEXT,
    committee_name VARCHAR(255),
    raw_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_prints_congress ON committee_prints(congress);
CREATE INDEX idx_prints_chamber ON committee_prints(chamber);

-- Update timestamp trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply update triggers
CREATE TRIGGER update_bills_updated_at BEFORE UPDATE ON bills
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_members_updated_at BEFORE UPDATE ON members
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Views for common queries
CREATE VIEW active_members AS
SELECT * FROM members
WHERE terms IS NOT NULL;

CREATE VIEW recent_bills AS
SELECT * FROM bills
WHERE congress >= 117
ORDER BY introduced_date DESC;

-- Grant permissions (adjust as needed)
-- GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO your_app_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO your_app_user;

COMMIT;

-- End of migration script
`;

  const blob = new Blob([sqlScript], { type: 'text/plain' });
  const filename = `congress_db_migration_${new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5)}.sql`;
  downloadFile(blob, filename);
  
  const card = event.target.closest('.card');
  const statusDiv = document.createElement('div');
  statusDiv.className = 'status status--success';
  statusDiv.textContent = `SQL migration script downloaded: ${filename}`;
  statusDiv.style.marginTop = 'var(--space-16)';
  card.appendChild(statusDiv);
  
  setTimeout(() => {
    statusDiv.remove();
  }, 5000);
}

// Auto-update summary when inputs change
document.addEventListener('DOMContentLoaded', function() {
  const summaryTriggers = ['congressStart', 'congressEnd', 'bulkFormat', 'bulkLimit', 'maxItems'];
  summaryTriggers.forEach(id => {
    const element = document.getElementById(id);
    if (element) {
      element.addEventListener('change', updateSummary);
    }
  });
  
  // Add change listeners to checkboxes
  const checkboxes = document.querySelectorAll('#endpointCheckboxes input[type="checkbox"]');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', updateSummary);
  });
  
  // Add CSS animation for progress bar
  const style = document.createElement('style');
  style.textContent = `
    @keyframes shimmer {
      0% { background-position: -200% 0; }
      100% { background-position: 200% 0; }
    }
  `;
  document.head.appendChild(style);
});